package ats.algo.icehockey;

import java.util.LinkedHashMap;
import java.util.Map;

import ats.algo.matchengineframework.MatchFormat;

public class IcehockeyMatchFormat extends MatchFormat {
    private int normalTimeMinutes;
    private int extraTimeMinutes;
    private boolean penaltiesPossible;
    
    public IcehockeyMatchFormat() {
        /*CJ*/
        // normalTimeMinutes = 90;
    	normalTimeMinutes = 60;
        extraTimeMinutes = 0;
        penaltiesPossible = false;
        GoalDistribution.setMatchLengthIs80Mins(false);
    }
    
    public int getNormalTimeMinutes() {
        return normalTimeMinutes;
    }
    
    public void setNormalTimeMinutes(int normalTimeMinutes) {
        this.normalTimeMinutes = normalTimeMinutes;
        GoalDistribution.setMatchLengthIs80Mins(normalTimeMinutes ==80);
    }
    
    public int getExtraTimeMinutes() {
        return extraTimeMinutes;
    }
    
    public void setExtraTimeMinutes(int extraTimeMinutes) {
        this.extraTimeMinutes = extraTimeMinutes;
    }
    
    public boolean isPenaltiesPossible() {
        return penaltiesPossible;
    }
    
    public void setPenaltiesPossible(boolean penaltiesPossible) {
        this.penaltiesPossible = penaltiesPossible;
    }
    
    private static final String normalTimeMinutesKey = "Length of normal time ( 60 minutes)";
    private static final String extraTimeMinutesKey = "Length of possible extra time (0/5 minutes)";
    private static final String penaltiesPossibleKey = "Match may be settled by penalties (Yes/No)";
    
    @Override
    public LinkedHashMap<String, String> getAsMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        map.put(normalTimeMinutesKey, String.format("%d", normalTimeMinutes));
        map.put(extraTimeMinutesKey, String.format("%d", extraTimeMinutes));
        String s;
        if (penaltiesPossible)
            s = "Yes";
        else
            s = "No";
        map.put(penaltiesPossibleKey, s);
        return map;
    }
    
    @Override
    public String setFromMap(Map<String, String> map) {
        String newValue = null;;
        String errorMessage = null;
        try {
            newValue = map.get(normalTimeMinutesKey);
            int n = Integer.parseInt(newValue);
            if (n != 80 && (n != 90))
                throw new Exception();
            setNormalTimeMinutes(n);
            newValue = map.get(extraTimeMinutesKey);
            n = Integer.parseInt(newValue);
            if (n != 0 && (n != 30))
                throw new Exception();
            setExtraTimeMinutes(n);
            newValue = map.get(penaltiesPossibleKey);
            switch (newValue.toUpperCase()) {
            case "YES":
                penaltiesPossible = true;
                break;
            case "NO":
                penaltiesPossible = false;
                break;
            default:
                throw new Exception();
            }
            
        } catch (Exception e) {
            errorMessage = String.format("Invalid input: %s.", newValue);
        }
        return errorMessage;
    }
    
}
