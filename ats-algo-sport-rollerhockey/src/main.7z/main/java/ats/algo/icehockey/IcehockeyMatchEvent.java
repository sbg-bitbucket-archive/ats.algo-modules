package ats.algo.icehockey;

import ats.algo.matchengineframework.MatchEvent;

class IcehockeyMatchEvent implements MatchEvent{
    
    enum IcehockeyMatchEventType {
    TIME_UNIT_ELAPSED_NO_GOAL,
    TIME_UNIT_ELAPSED_HOME_GOAL,
    TIME_UNIT_ELAPSED_AWAY_GOAL,
    POWERPLAY_STARTED_H,
    POWERPLAY_STARTED_A,
    POWERPLAY_ENDED,
    SET_INJURY_TIME
    }
    
    private IcehockeyMatchEventType eventType;
    private int injuryTimeSecs;
    
    void set(IcehockeyMatchEventType eventType) {
        this.eventType = eventType;
        this.injuryTimeSecs = 0;
    }
    
    void set(IcehockeyMatchEventType eventType, int injuryTimeSecs) {
        this.eventType = eventType;
        this.injuryTimeSecs = injuryTimeSecs;
    }

    
    IcehockeyMatchEventType getEventType() {
        return eventType;
    }

    int getInjuryTimeSecs() {
        return injuryTimeSecs;
    }
    
    
}
