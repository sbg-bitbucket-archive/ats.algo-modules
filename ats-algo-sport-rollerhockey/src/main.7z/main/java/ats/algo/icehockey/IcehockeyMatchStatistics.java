package ats.algo.icehockey;

import ats.algo.montecarloframework.MonteCarloStatistics;
import ats.algo.montecarloframework.TeamId;

public class IcehockeyMatchStatistics extends MonteCarloStatistics {
    
    /**
     * holds any facts about a simulation of a match that has just been played (via the Match class)
     * that are need in the calculation of the required statistics and that are not captured by the matchState object
     * for Football if we need to know who won leg N+2, where N is the current leg, then we 
     * need to collect that "fact" in this class  
     * @author Geoff
     *
     */
    
    private ThreeWayStatistic matchWinner;
    private CorrectScoreStatistic correctGoalScore;
    private TotalStatistic goalsTotal;
    private TotalStatistic goalsTotalH;
    private TotalStatistic goalsTotalA;
    private HandicapStatistic goalsHandicap;
    private ThreeWayStatistic nextGoal;
    
    private static final int maxNoGoalsPerTeam = 40;
    
    IcehockeyMatchStatistics () {
        
        matchWinner = new ThreeWayStatistic("AB", "Match winner", "Home", "Away", "Draw");
        correctGoalScore = new CorrectScoreStatistic("CS", "Match correct score", maxNoGoalsPerTeam);
        goalsTotal = new TotalStatistic("GT", "Match total goals", 2*maxNoGoalsPerTeam);
        goalsTotalH = new TotalStatistic("GTH", "Match total goals home team", maxNoGoalsPerTeam);
        goalsTotalA = new TotalStatistic("GTA", "Match total goals away team", maxNoGoalsPerTeam);
        goalsHandicap = new HandicapStatistic ("LHCAP", "A", "B", "Match handicap", maxNoGoalsPerTeam);
        nextGoal = new ThreeWayStatistic("NG", "Next team to score", "Home", "Away", "Draw");
        
    }
    
    void updateStats (IcehockeyMatchState matchState, IcehockeyMatchFacts matchFacts) {
        int goalsA = matchState.getGoalsHome();
        int goalsB = matchState.getGoalsAway();
        TeamId teamId = TeamId.UNKNOWN;        
        if (goalsA>goalsB)
            teamId = TeamId.A;
        if(goalsA<goalsB)
            teamId = TeamId.B;
        matchWinner.increment (teamId);
        correctGoalScore.increment(goalsA, goalsB);
        goalsTotal.increment(goalsA+goalsB);
        goalsTotalH.increment(goalsA);
        goalsTotalA.increment(goalsB);
        goalsHandicap.increment(goalsA-goalsB);
        nextGoal.increment(matchFacts.getNextToScore());
    }
    

}
