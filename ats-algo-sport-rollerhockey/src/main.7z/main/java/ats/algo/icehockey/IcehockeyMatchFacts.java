package ats.algo.icehockey;

import ats.algo.montecarloframework.TeamId;

/**
 * container for data collected during the simulation of a match
 * @author Geoff
 *
 */
class IcehockeyMatchFacts {
    TeamId nextToScore;
    
    
    void reset() {
        nextToScore = TeamId.UNKNOWN;
    }
    
    TeamId getNextToScore() {
        return nextToScore;
    }
    
    void setNextToScore(TeamId nextToScore) {
        this.nextToScore = nextToScore;
    }
    
}
