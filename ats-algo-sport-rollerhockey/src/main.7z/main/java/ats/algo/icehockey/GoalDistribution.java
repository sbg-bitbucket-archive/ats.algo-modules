package ats.algo.icehockey;

public class GoalDistribution {
    
    private static int timeIncrementSecs = 10;
    private static int periodsPerMinute = 6;
    private static boolean matchLengthIs80Mins = false;
    
    /**
     * determines the time related distribution of goals throughout the match
     * 
     * @param timeIncrementSecs
     *            - the time intervals used by the model
     * @param halfTimeSecs
     *            - the length of each half in normal time
     * @param extraTimeSecs
     *            - the length of each half in extra
     */
    static void setTimeIncrementSecs(int timeIncrementSecs) {
        GoalDistribution.timeIncrementSecs = timeIncrementSecs;
        GoalDistribution.periodsPerMinute = 60 / timeIncrementSecs;
    }
    
    static void setMatchLengthIs80Mins(boolean value) {
        matchLengthIs80Mins = value;
    }
    
    static double getGoalDistribution(IcehockeyMatchPeriod matchPeriod, int elapsedTimeSecs, int injuryTimeSecs) {
        if (matchPeriod == IcehockeyMatchPeriod.IN_EXTRA_TIME_FIRST_QUATER
                || matchPeriod == IcehockeyMatchPeriod.IN_EXTRA_TIME_SECOND_QUATER
                || matchPeriod == IcehockeyMatchPeriod.IN_EXTRA_TIME_FIRST_QUATER_TIME)
            return determineExtraMinsGoalDistribution(matchPeriod, elapsedTimeSecs, injuryTimeSecs);
        if (matchLengthIs80Mins)
            return determine80MinsGoalDistribution(matchPeriod, elapsedTimeSecs, injuryTimeSecs);
        else
            return determine60MinsGoalDistribution(matchPeriod, elapsedTimeSecs, injuryTimeSecs);
    }
    
    private static double determine60MinsGoalDistribution(IcehockeyMatchPeriod matchPeriod, int elapsedTimeSecs,
            int injuryTimeSecs) {
        double goalDist;
        int period = elapsedTimeSecs / timeIncrementSecs;
        
        if (period < 15 * periodsPerMinute) {
            goalDist = 0.11 / (periodsPerMinute * 15);
        } else if (period < 30 * periodsPerMinute) {
            goalDist = 0.14 / (periodsPerMinute * 15);
        } else if (matchPeriod == IcehockeyMatchPeriod.IN_FIRST_THIRDS) {
            goalDist = 0.17 / (periodsPerMinute * (15 + injuryTimeSecs / 60));
        } else if (period < 60 * periodsPerMinute) {
            goalDist = 0.15 / (periodsPerMinute * 15);
        } else if (period < 75 * periodsPerMinute) {
            goalDist = 0.19 / (periodsPerMinute * 15);
        } else {
            goalDist = 0.24 / (periodsPerMinute * (15 + injuryTimeSecs / 60));
        }
        return goalDist;
    }
    
    private static double determine80MinsGoalDistribution(IcehockeyMatchPeriod matchPeriod, int elapsedTimeSecs,
            int injuryTimeSecs) {
        double goalDist;
        int period = elapsedTimeSecs / timeIncrementSecs;
        
        if (period < 10 * periodsPerMinute) {
            goalDist = 0.09 / (periodsPerMinute * 10);
        } else if (period < 20 * periodsPerMinute) {
            goalDist = 0.10 / (periodsPerMinute * 10);
        } else if (period < 30 * periodsPerMinute) {
            goalDist = 0.11 / (periodsPerMinute * 10);
        } else if (matchPeriod == IcehockeyMatchPeriod.IN_FIRST_THIRDS) {
            goalDist = 0.13 / (periodsPerMinute * (10 + injuryTimeSecs / 60));
        } else if (period < 50 * periodsPerMinute) {
            goalDist = 0.11 / (periodsPerMinute * 10);
        } else if (period < 60 * periodsPerMinute) {
            goalDist = 0.12 / (periodsPerMinute * 10);
        } else if (period < 70 * periodsPerMinute) {
            goalDist = 0.16 / (periodsPerMinute * 10);
        } else {
            goalDist = 0.18 / (periodsPerMinute * (10 + injuryTimeSecs / 60));
        }
        return goalDist;
    }
    
    static double determineExtraMinsGoalDistribution(IcehockeyMatchPeriod matchPeriod, int elapsedTimeSecs,
            int injuryTimeSecs) {
        double goalDist;
        int period = elapsedTimeSecs / timeIncrementSecs;
        if (period < 5 * periodsPerMinute) {
            goalDist = 0.12 / (periodsPerMinute * 5);
        } else if (period < 10 * periodsPerMinute) {
            goalDist = 0.15 / (periodsPerMinute * 5);
        } else if (matchPeriod == IcehockeyMatchPeriod.IN_EXTRA_TIME_FIRST_QUATER) {
            goalDist = 0.19 / (periodsPerMinute * (5 + injuryTimeSecs / 60));
        } else if (period < 20 * periodsPerMinute) {
            goalDist = 0.12 / (periodsPerMinute * 5);
        } else if (period < 25 * periodsPerMinute) {
            goalDist = 0.17 / (periodsPerMinute * 5);
        } else {
            goalDist = 0.25 / (periodsPerMinute * (5 + injuryTimeSecs / 60));
        }
        return goalDist;
    }
    
}
