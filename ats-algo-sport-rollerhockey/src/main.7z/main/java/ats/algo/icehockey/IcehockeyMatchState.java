package ats.algo.icehockey;

import java.util.LinkedHashMap;
import java.util.Map;

import ats.algo.icehockey.IcehockeyMatchEvent.IcehockeyMatchEventType;
import ats.algo.matchengineframework.MatchEvent;
import ats.algo.matchengineframework.MatchEventPrompt;
import ats.algo.matchengineframework.MatchEventResult;
import ats.algo.matchengineframework.MatchFormat;
import ats.algo.matchengineframework.MatchState;

public class IcehockeyMatchState extends MatchState {
    /*CJ add send off H, send off A*/
	private int sendOffTimer_H;
	private int sendOffTimer_A;
	private int sendOffHome;
	private int sendOffAway;
	
    private int goalsHome;
    private int goalsAway;
    private int elapsedTimeSecs;
    private int elapsedTimeThisPeriodSecs;
    private int injuryTimeSecs;
    private IcehockeyMatchPeriod matchPeriod; // the state following the most recent MatchEvent;
    
    private final int normalQuaterSecs;
    private final int extraQuaterSecs;
    private final IcehockeyMatchFormat matchFormat;
    private static final int timeIncrementSecs = 10;  
    
    public IcehockeyMatchState(MatchFormat matchFormat) {
        this.matchFormat = (IcehockeyMatchFormat) matchFormat;
        matchPeriod = IcehockeyMatchPeriod.PREMATCH;
        /*Geoff's Original Code
        normalHalfSecs = this.matchFormat.getNormalTimeMinutes() * 30;  
        extraHalfSecs = this.matchFormat.getExtraTimeMinutes() * 30;
        */
        
        /*CJ changed normalHalfSecs to normalQuaterSecs*/
        
        normalQuaterSecs = this.matchFormat.getNormalTimeMinutes() * 20; /*CJ WANT TO CHANGE TO 20 SECS*/
        extraQuaterSecs = this.matchFormat.getExtraTimeMinutes() * 20;
    
    }
    
    /*CJ added sent off methods */
    public int getSendOffHome() {
        return sendOffHome;
    }
    
    public void setSendOffHome(int sendOffH) {
        this.sendOffHome = sendOffH;
    }
    
    public int getSendOffAway() {
        return sendOffAway;
    }
    
    public void setSendOffAway(int sendOffA) {
        this.sendOffAway = sendOffA;
    }
    
    
    
    
    public int getGoalsHome() {
        return goalsHome;
    }
    
    public void setGoalsHome(int goalsHome) {
        this.goalsHome = goalsHome;
    }
    
    public int getGoalsAway() {
        return goalsAway;
    }
    
    public void setGoalsAway(int goalsAway) {
        this.goalsAway = goalsAway;
    }
    
    public int getElapsedTimeSecs() {
        return elapsedTimeSecs;
    }
    
    public int getElapsedTimeThisPeriodSecs() {
        return elapsedTimeThisPeriodSecs;
    }
    
    /* Geoff's original method 
    public void setElapsedTimeSecs(int elapsedTimeSecs) {
        this.elapsedTimeSecs = elapsedTimeSecs;
        this.elapsedTimeThisPeriodSecs = elapsedTimeSecs;
        matchPeriod = IcehockeyMatchPeriod.IN_FIRST_HALF;
        if (elapsedTimeSecs > normalHalfSecs) {
            this.elapsedTimeThisPeriodSecs -= normalHalfSecs;
            matchPeriod = IcehockeyMatchPeriod.IN_SECOND_HALF;
        }
        if (elapsedTimeSecs > 2 * normalHalfSecs) {
            this.elapsedTimeThisPeriodSecs -= normalHalfSecs;
            matchPeriod = IcehockeyMatchPeriod.IN_EXTRA_TIME_FIRST_HALF;
        }
        if (elapsedTimeSecs > 2 * normalHalfSecs + extraHalfSecs) {
            this.elapsedTimeThisPeriodSecs -= extraHalfSecs;
            matchPeriod = IcehockeyMatchPeriod.IN_EXTRA_TIME_SECOND_HALF;
        }
    }
    */
    /* Jin's Change, refactory IN_FIRST_HALF to IN_FIRST_THIRDS*/
    public void setElapsedTimeSecs(int elapsedTimeSecs) {
        this.elapsedTimeSecs = elapsedTimeSecs;
        this.elapsedTimeThisPeriodSecs = elapsedTimeSecs;
        matchPeriod = IcehockeyMatchPeriod.IN_FIRST_THIRDS;
        
        if (elapsedTimeSecs > normalQuaterSecs) {
            this.elapsedTimeThisPeriodSecs -= normalQuaterSecs;
            matchPeriod = IcehockeyMatchPeriod.IN_SECOND_THIRDS;
        }
        if (elapsedTimeSecs > 2 * normalQuaterSecs) {
            this.elapsedTimeThisPeriodSecs -= normalQuaterSecs;
            matchPeriod = IcehockeyMatchPeriod.IN_THIRD_THIRDS;
        }
      
        
    /*
     * CJ added third quater discern
     * */
        if (elapsedTimeSecs > 3 * normalQuaterSecs) {
            this.elapsedTimeThisPeriodSecs -= normalQuaterSecs;
            matchPeriod = IcehockeyMatchPeriod.IN_EXTRA_TIME_THIRD_QUATER;
        }
        if (elapsedTimeSecs > 3 * normalQuaterSecs + extraQuaterSecs) {
            this.elapsedTimeThisPeriodSecs -= 2*extraQuaterSecs;
            matchPeriod = IcehockeyMatchPeriod.IN_EXTRA_TIME_SECOND_QUATER;
        }
    
    }
    
    public int getInjuryTimeSecs() {
        return injuryTimeSecs;
    }
    
    public void setInjuryTimeSecs(int injuryTimeSecs) {
        this.injuryTimeSecs = injuryTimeSecs;
    }
    
    public IcehockeyMatchPeriod getMatchPeriod() {
        return matchPeriod;
    }
    
    public void setMatchPeriod(IcehockeyMatchPeriod matchPeriod) {
        this.matchPeriod = matchPeriod;
    }
    
    @Override
    public MatchEventResult updateStateForEvent(MatchEvent matchEvent) {
        switch (((IcehockeyMatchEvent) matchEvent).getEventType()) {
        /*
         * CJ added powerplay_started and powerplay_ended
         * */
        case POWERPLAY_STARTED_H:
            elapsedTimeSecs += timeIncrementSecs;
            elapsedTimeThisPeriodSecs += timeIncrementSecs; 
            sendOffTimer_H = elapsedTimeSecs; // defaultsetted to be 2 minutes
            sendOffHome=1;
            break; 
        case POWERPLAY_STARTED_A:
            elapsedTimeSecs += timeIncrementSecs;
            elapsedTimeThisPeriodSecs += timeIncrementSecs;
            sendOffTimer_A = elapsedTimeSecs; // defaultsetted to be 2 minutes
            sendOffAway=1;
            break; 
        
        case TIME_UNIT_ELAPSED_NO_GOAL:
        	if(elapsedTimeSecs-sendOffTimer_H>120) // if greater than 120 seconds, 2 mins send away
        	{sendOffHome=0;}
        	if(elapsedTimeSecs-sendOffTimer_A>120) // if greater than 120 seconds
        	{sendOffAway=0;}
            
        	elapsedTimeSecs += timeIncrementSecs;
            elapsedTimeThisPeriodSecs += timeIncrementSecs;
            break;
        case TIME_UNIT_ELAPSED_HOME_GOAL:
        	if(elapsedTimeSecs-sendOffTimer_H>120) // if greater than 120 seconds
        	{sendOffHome=0;}
        	if(elapsedTimeSecs-sendOffTimer_A>120) // if greater than 120 seconds
        	{sendOffAway=0;}
        	
            elapsedTimeSecs += timeIncrementSecs;
            elapsedTimeThisPeriodSecs += timeIncrementSecs;
            goalsHome++;
            break;
        case TIME_UNIT_ELAPSED_AWAY_GOAL:
        	if(elapsedTimeSecs-sendOffTimer_H>120) // if greater than 120 seconds
        	{sendOffHome=0;}
        	if(elapsedTimeSecs-sendOffTimer_A>120) // if greater than 120 seconds
        	{sendOffAway=0;}
        	
            elapsedTimeSecs += timeIncrementSecs;
            elapsedTimeThisPeriodSecs += timeIncrementSecs;
            goalsAway++;
            break;
        case SET_INJURY_TIME:
            injuryTimeSecs = ((IcehockeyMatchEvent) matchEvent).getInjuryTimeSecs();
            break;
        }
        
        
        switch (matchPeriod) {
        case PREMATCH:
            matchPeriod = IcehockeyMatchPeriod.IN_FIRST_THIRDS;
        case IN_FIRST_THIRDS: 
            if (endOfPeriodNormalTime()) {
                matchPeriod = IcehockeyMatchPeriod.AT_FIRST_THIRDS_TIME;
                elapsedTimeThisPeriodSecs = 0;
                injuryTimeSecs = 0;
                elapsedTimeSecs = normalQuaterSecs;
            }
            break;
        case AT_FIRST_THIRDS_TIME:
            matchPeriod = IcehockeyMatchPeriod.IN_SECOND_THIRDS;
            break;
        case IN_SECOND_THIRDS:
            if (endOfPeriodNormalTime()) {
                    matchPeriod = IcehockeyMatchPeriod.AT_SECOND_THIRDS_TIME;
                    elapsedTimeThisPeriodSecs = 0;
                    injuryTimeSecs = 0;
                    elapsedTimeSecs = 2 * normalQuaterSecs;
           }
            break;
        case AT_SECOND_THIRDS_TIME:
            matchPeriod = IcehockeyMatchPeriod.IN_THIRD_THIRDS;
            break;
        case IN_THIRD_THIRDS:
            if (endOfPeriodNormalTime()) {
                if (extraQuaterSecs == 0) {
                    matchPeriod = IcehockeyMatchPeriod.MATCH_COMPLETED;
                    elapsedTimeThisPeriodSecs = normalQuaterSecs;
                    elapsedTimeSecs = 3 * normalQuaterSecs;
                }
                else {
                    matchPeriod = IcehockeyMatchPeriod.AT_FULL_TIME;
                    elapsedTimeThisPeriodSecs = 0;
                    injuryTimeSecs = 0;
                    elapsedTimeSecs = 3 * normalQuaterSecs;
                }
            }
            break;
        case AT_FULL_TIME:
            matchPeriod = IcehockeyMatchPeriod.IN_EXTRA_TIME_FIRST_QUATER;
            break;
                       
        case IN_EXTRA_TIME_FIRST_QUATER:
            if (endOfPeriodExtraTime()) {
                matchPeriod = IcehockeyMatchPeriod.IN_EXTRA_TIME_FIRST_QUATER_TIME;
                elapsedTimeThisPeriodSecs = 0;
                injuryTimeSecs = 0;
                elapsedTimeSecs = 3 * normalQuaterSecs + extraQuaterSecs;
            }
            break;
        case IN_EXTRA_TIME_FIRST_QUATER_TIME:
            matchPeriod = IcehockeyMatchPeriod.IN_EXTRA_TIME_SECOND_QUATER;
            break;
        case IN_EXTRA_TIME_SECOND_QUATER:
            if (endOfPeriodExtraTime()) {
                matchPeriod = IcehockeyMatchPeriod.MATCH_COMPLETED;
                elapsedTimeThisPeriodSecs = 0;
                injuryTimeSecs = 0;
                elapsedTimeSecs = 3 * (normalQuaterSecs + extraQuaterSecs);
            }
            break;
        case MATCH_COMPLETED:
            elapsedTimeThisPeriodSecs = 0;
            throw new IllegalArgumentException("MATCH_COMPLETED not a valid state");
        }
        return matchPeriod;
    }
    
    private boolean endOfPeriodNormalTime() {
        return elapsedTimeThisPeriodSecs >= normalQuaterSecs + injuryTimeSecs;
    }
    
    private boolean endOfPeriodExtraTime() {
        return elapsedTimeThisPeriodSecs >= extraQuaterSecs + injuryTimeSecs;
    }
    
    @Override
    public MatchState copy() {
    	IcehockeyMatchState cc = new IcehockeyMatchState(matchFormat);
        cc.setEqualTo(this);
        return cc;
        
    }
    
    @Override
    public void setEqualTo(MatchState matchState) {
        this.setGoalsHome(((IcehockeyMatchState) matchState).getGoalsHome());
        this.setGoalsAway(((IcehockeyMatchState) matchState).getGoalsAway());
        this.setElapsedTimeSecs(((IcehockeyMatchState) matchState).getElapsedTimeSecs());
        this.setInjuryTimeSecs(((IcehockeyMatchState) matchState).getInjuryTimeSecs());
        this.setMatchPeriod(((IcehockeyMatchState) matchState).getMatchPeriod());
        /*CJ amended*/
        this.setSendOffHome(((IcehockeyMatchState) matchState).getSendOffHome());
        this.setSendOffHome(((IcehockeyMatchState) matchState).getSendOffHome());
    }
    
    @Override
    public MatchEventPrompt getNextPrompt() {
        MatchEventPrompt matchEventPrompt = null;
        if (matchPeriod == IcehockeyMatchPeriod.MATCH_COMPLETED)
            matchEventPrompt = new MatchEventPrompt("Match finished");
        else
            matchEventPrompt = new MatchEventPrompt(
                    "Next event (Nnn-Nothing happened for nn periods, H-Home goal, A-Away goal, 1-Home player send-off, 2-Away player send-off)", "N");
        return matchEventPrompt;
    }
    
    @Override
    public MatchEventResult getMatchEventResult(String response) {
    	IcehockeyMatchEventType matchEventType = null;
        int injuryTime = 0;
        int repeatCount = 1;
        char c = response.toUpperCase().charAt(0);
        switch (c) {
        case 'N':
            matchEventType = IcehockeyMatchEventType.TIME_UNIT_ELAPSED_NO_GOAL;
            try {
                repeatCount = Integer.parseInt(response.substring(1));
                if (repeatCount < 0 || repeatCount > 500)
                    repeatCount = 1;
            } catch (Exception e) {
                repeatCount = 1;
            }
            break;
        case 'H':
            matchEventType = IcehockeyMatchEventType.TIME_UNIT_ELAPSED_HOME_GOAL;
            break;
        case 'A':
            matchEventType = IcehockeyMatchEventType.TIME_UNIT_ELAPSED_AWAY_GOAL;
            break;
        case '1':
            matchEventType = IcehockeyMatchEventType.POWERPLAY_STARTED_H;
            break;
        case '2':
            matchEventType = IcehockeyMatchEventType.POWERPLAY_STARTED_A;
            break;               
        case 'I':
            matchEventType = IcehockeyMatchEventType.SET_INJURY_TIME;
            try {
                injuryTime = Integer.parseInt(response.substring(1));
                if (injuryTime < 0 || injuryTime > 1000)
                    throw new Exception();
            } catch (Exception e) {
                return null;
            }
            break;
        default:
            return null; // invalid input so return null
        }
        for (int i = 0;i<repeatCount;i++) {
            IcehockeyMatchEvent event = new IcehockeyMatchEvent();
            event.set(matchEventType, injuryTime);
            matchPeriod = (IcehockeyMatchPeriod) updateStateForEvent(event);
        }        
        return matchPeriod;
    }
    
    private static final String goalsKey = "Goals";
    private static final String elapsedTimeKey = "Elapsed time";
    private static final String injuryTimeKey = "Injury time to be played";
    private static final String matchPeriodKey = "Match period";
    
    @Override
    public LinkedHashMap<String, String> getAsMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        map.put(goalsKey, String.format("%d-%d", goalsHome, goalsAway));
        int mins = elapsedTimeSecs / 60;
        int secs = elapsedTimeSecs - mins * 60;
        map.put(elapsedTimeKey, String.format("%d:%02d", mins, secs));
        mins = injuryTimeSecs / 60;
        secs = injuryTimeSecs - mins * 60;
        map.put(injuryTimeKey, String.format("%d:%02d", mins, secs));
        map.put(matchPeriodKey, matchPeriod.toString());
        return map;
    }
    
    @Override
    public String setFromMap(Map<String, String> map) {
        /*
         * do nothing - not allowing the user to manually update the score
         */
        return null;
    }
    
    @Override
    public boolean isMatchCompleted() {
        return (matchPeriod == IcehockeyMatchPeriod.MATCH_COMPLETED);
    }
    
}
