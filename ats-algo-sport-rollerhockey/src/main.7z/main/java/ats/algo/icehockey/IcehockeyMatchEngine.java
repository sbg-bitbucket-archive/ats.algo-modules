package ats.algo.icehockey;

import ats.algo.montecarloframework.matchengine.MonteCarloMatchEngine;

public class IcehockeyMatchEngine extends MonteCarloMatchEngine{

    public IcehockeyMatchEngine(IcehockeyMatchFormat matchFormat) {
        matchParams = new IcehockeyMatchParams();
        matchParams.setDefaultParams(matchFormat);        
        matchState = new IcehockeyMatchState(matchFormat);
        match = new IcehockeyMatch(matchFormat, (IcehockeyMatchState) matchState, 
                (IcehockeyMatchParams) matchParams);  
        initialiseConcurrentCalculationManager();
    }

}
