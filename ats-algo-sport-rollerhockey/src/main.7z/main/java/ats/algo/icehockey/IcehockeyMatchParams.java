package ats.algo.icehockey;

import java.util.LinkedHashMap;

import ats.algo.genericsupportfunctions.Gaussian;
import ats.algo.matchengineframework.MatchEventResult;
import ats.algo.matchengineframework.MatchFormat;
import ats.algo.matchengineframework.MatchParam;
import ats.algo.matchengineframework.MatchParams;
import ats.algo.matchengineframework.MatchParam.MatchParamType;

public class IcehockeyMatchParams extends MatchParams {

    
    private MatchParam homeScoreRate;
    private MatchParam awayScoreRate;
    private MatchParam homeLoseBoost;
    private MatchParam awayLoseBoost;
 

    private double playerBoostRate = 2;
    
    public IcehockeyMatchParams() {
        setDefaultParams();
        
    }
    
    /*
     * getters and setters come in two flavours - setting and returning the matchParam or the underlying gaussian
     */
    
    
    void setHomeScoreRate(MatchParam homeScoreRate) {
        this.homeScoreRate = homeScoreRate;
    }
    
    public void setHomeScoreRate(double skill, double stdDevn) {
        this.homeScoreRate.setParam(skill, stdDevn);
    }
    
    void setAwayScoreRate(MatchParam awayScoreRate) {
        this.awayScoreRate = awayScoreRate;
    }
    
    public void setAwayScoreRate(double skill, double stdDevn) {
        this.awayScoreRate.setParam(skill, stdDevn);
    }
    
    void setHomeLoseBoost(MatchParam homeLoseBoost) {
        this.homeLoseBoost = homeLoseBoost;
    }
    
    public void setHomeLoseBoost(double skill, double stdDevn) {
        this.homeLoseBoost.setParam(skill, stdDevn);
    }
    
    void setAwayLoseBoost(MatchParam awayLoseBoost) {
        this.awayLoseBoost = awayLoseBoost;
    }
    
    public void setAwayLoseBoost(double skill, double stdDevn) {
        this.awayLoseBoost.setParam(skill, stdDevn);
    }
    /*CJ added, pass boost status from MatchState, iceHockeyMatch*/
    public boolean powerPlayBoostH;
    public boolean powerPlayBoostA;
    
    public void setpowerPlayBoostH(boolean powerPlayBoostHin) {
        this.powerPlayBoostH = powerPlayBoostHin;
    }
    
    public void setpowerPlayBoostA(boolean powerPlayBoostAin) {
        this.powerPlayBoostA = powerPlayBoostAin;
    }
    
    MatchParam getHomeScoreRate() {
    	/*boost should be added here*/
        if(powerPlayBoostH){   
    	 double boostedMean = homeScoreRate.getParam().getMean()*playerBoostRate;
    	 double stdDevnH = homeScoreRate.getParam().getStdDevn();
    	 MatchParam boostedMatchParam = new MatchParam(MatchParamType.PENALTYBOOSTA, "probAWinsLeg", boostedMean, stdDevnH);
    	 return boostedMatchParam;
    	 }
        else{
    	return homeScoreRate;	
    	} 
    }
    
    MatchParam getAwayScoreRate() {
        if(powerPlayBoostA){   
    	 double boostedMean = awayScoreRate.getParam().getMean()*playerBoostRate;
    	 double stdDevnA = awayScoreRate.getParam().getStdDevn();
    	 MatchParam boostedMatchParam = new MatchParam(MatchParamType.PENALTYBOOSTB, "probAWinsLeg", boostedMean, stdDevnA);
        return boostedMatchParam;}
        else{
    	return awayScoreRate;
    	}
    }
    
    
    public Gaussian getHomeScoreRateAsGaussian() {
        return homeScoreRate.getParam();
    }
    

    public Gaussian getAwayScoreRateAsGaussian() {
        return awayScoreRate.getParam();
    }
    
    MatchParam getHomeLoseBoost() {
        return homeLoseBoost;
    }
    public Gaussian getHomeLoseBoostAsGaussian() {
        return homeLoseBoost.getParam();
    }

    MatchParam getAwayLoseBoost() {
        return awayLoseBoost;
    }
    public Gaussian getAwayLoseBoostAsGaussian() {
        return awayLoseBoost.getParam();
    }
    
    
    
    @Override
    public MatchParams copy() {
    	IcehockeyMatchParams cc = new IcehockeyMatchParams();
        cc.setEqualTo(this);
        return cc;
    }
    
    @Override
    public void setEqualTo(MatchParams matchParams) {
        this.setHomeScoreRate(((IcehockeyMatchParams) matchParams).getHomeScoreRate());
        this.setAwayScoreRate(((IcehockeyMatchParams) matchParams).getAwayScoreRate());
        this.setHomeLoseBoost(((IcehockeyMatchParams) matchParams).getHomeLoseBoost());
        this.setAwayLoseBoost(((IcehockeyMatchParams) matchParams).getAwayLoseBoost());
    }
    
    private static final String homeScoreRateKey = "Home team goal score rate";
    private static final String awayScoreRateKey = "Away team goal score rate";
    private static final String homeLoseBoostKey = "Home team rate boost when losing";
    private static final String awayLoseBoostKey = "Away team rate boost when losing";
    
    @Override
    public void setDefaultParams(MatchFormat matchFormat) {
        setDefaultParams(); // defaults don't depend on match format for now
    }
    
    private void setDefaultParams() {
        homeScoreRate = new MatchParam(MatchParamType.A, homeScoreRateKey, 1.5, 0.05);
        awayScoreRate = new MatchParam(MatchParamType.B, awayScoreRateKey, 1.2, 0.05);
        homeLoseBoost = new MatchParam(MatchParamType.A, homeLoseBoostKey, 0.2, 0.005);
        awayLoseBoost = new MatchParam(MatchParamType.B, awayLoseBoostKey, 0.1, 0.005);
     
    }
    
    /**
     * this function is passed to the momentum updating logic in . In this case it is a very simple function, since x[0]
     * is the prob that A wins a Leg
     * 
     * @param x
     * @return
     */
    /*
    private double probAWinsLegGivenX(double[] x) {
        return x[0];
    }
    */
    
    @Override
    public void updateParamsGivenMatchEventResult(MatchEventResult matchEventResult) {
        // TODO
        /*
         * Bayes bayes = new Bayes(1, (double[] z) -> probAWinsLegGivenX(z)); Gaussian[] params = new Gaussian[1];
         * params[0] = probAWinsLeg.getParam(); bayes.setPriorParams(params); bayes.updateSkills(playerAWonLeg); params
         * = bayes.getPosteriorParams(); probAWinsLeg.setParam(params[0]);
         */
    }
    
    @Override
    public LinkedHashMap<String, MatchParam> getAsMap() {
        
        LinkedHashMap<String, MatchParam> map = new LinkedHashMap<String, MatchParam>();
        MatchParam cc = homeScoreRate.copy();
        map.put(cc.getParamName(), cc);
        cc = awayScoreRate.copy();
        map.put(cc.getParamName(), cc);
        cc = homeLoseBoost.copy();
        map.put(cc.getParamName(), cc);
        cc = awayLoseBoost.copy();
        map.put(cc.getParamName(), cc);
        return map;
    }
    
    @Override
    public String setFromMap(LinkedHashMap<String, MatchParam> map) {
        MatchParam p;
        String paramInError = "param-4*stdDevn must be >0: ";
        try {
            paramInError += homeScoreRateKey;
            p = map.get(homeScoreRateKey);
            if (paramIsOk(p.getParam())) {
                this.setHomeScoreRate(p);
            } else
                throw new Exception();
            paramInError += awayScoreRateKey;
            p = map.get(awayScoreRateKey);
            if (paramIsOk(p.getParam())) {
                this.setAwayScoreRate(p);
            } else
                throw new Exception();
            paramInError += homeLoseBoostKey;
            p = map.get(homeLoseBoostKey);
            if (paramIsOk(p.getParam())) {
                this.setHomeLoseBoost(p);
            } else
                throw new Exception();
            paramInError += awayLoseBoostKey;
            p = map.get(awayLoseBoostKey);
            if (paramIsOk(p.getParam())) {
                this.setAwayLoseBoost(p);
            } else
                throw new Exception();            
        } catch (Exception e) {
            return paramInError;
        }
        return null;
    }
    
    /**
     * checks that the supplied parameter passes basic sanity tests, e.g. >0. Also verifies that mean+-4*stdDevn remains
     * positive
     *
     * @param g
     * @return
     */
    private boolean paramIsOk(Gaussian g) {
        double mean = g.getMean();
        double stdDevn = g.getStdDevn();
        boolean paramOk = (mean > 0) && (mean < 20);
        paramOk = paramOk && (stdDevn > 0);
        paramOk = paramOk && (mean - 4 * stdDevn >0);
        return paramOk;
    }
    
}
