package ats.algo.icehockey;

import ats.algo.matchengineframework.MatchEventResult;

/**
 * 
 * @author Geoff
 *        
 */
enum IcehockeyMatchPeriod implements MatchEventResult { 
        PREMATCH,
        IN_FIRST_THIRDS, 
        AT_FIRST_THIRDS_TIME, 
        IN_SECOND_THIRDS, 
        AT_SECOND_THIRDS_TIME, 
        IN_THIRD_THIRDS, //CJ ADD
        AT_FULL_TIME,//CJ ADD 
        
        IN_EXTRA_TIME_FIRST_QUATER, 
        IN_EXTRA_TIME_FIRST_QUATER_TIME,
        IN_EXTRA_TIME_SECOND_QUATER, 
        IN_EXTRA_TIME_THIRD_QUATER, 
        MATCH_COMPLETED
}
